#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os

class DefaultConfig:
    """ Bot Configuration """

    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "f54e4567-a2e9-4a5b-949d-89617677a78c")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "H9d8Q~QyM76aqhzE.jFR_7FBaTOVxZFs3c6lpbjc")
    APP_TYPE = os.environ.get("MicrosoftAppType", "SingleTenant")
    APP_TENANTID = os.environ.get("MicrosoftAppTenantId", "ac58a972-b23a-4cf7-a09e-ac384ce8a7ed")
